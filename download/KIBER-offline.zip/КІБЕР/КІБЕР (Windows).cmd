@echo off
chcp 65001 >nul
set "F=%~dp0КІБЕР.app\Contents\Resources\kiber-data\index.html"
set "U=file:///%F:\=/%"
for %%B in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe") do (
  if exist %%B (
    start "" %%B --app="%U%" --window-size=1200,860
    exit /b
  )
)
start "" "%F%"
